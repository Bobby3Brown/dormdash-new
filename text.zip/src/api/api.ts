import axios from 'axios';

const BASE = 'http://localhost:2100';
const api = axios.create({ baseURL: BASE, timeout: 5000 });

// Simple token handling: store token in localStorage and attach to requests
export function setAuthToken(token: string | null) {
  if (token) {
    localStorage.setItem('dormdash_token', token);
    api.defaults.headers.common['Authorization'] = `Bearer ${token}`;
  } else {
    localStorage.removeItem('dormdash_token');
    delete api.defaults.headers.common['Authorization'];
  }
}

// Initialize token from storage if present
const _stored = localStorage.getItem('dormdash_token');
if (_stored) {
  api.defaults.headers.common['Authorization'] = `Bearer ${_stored}`;
}

// Auth
export async function login(email: string, password: string) {
  const res = await api.post('/auth/login', { email, password });
  return res.data;
}

export async function signup(email: string, password: string) {
  const res = await api.post('/auth/signup', { email, password });
  return res.data;
}

export async function authTest() {
  const res = await api.get('/auth/test');
  return res.data;
}

// Root health check
export async function health() {
  const res = await api.get('/');
  return res.data;
}

// Profile
export async function createProfile(profile: {
  fullName: string;
  email: string;
  mode: string;
  number: string;
  password: string;
  level?: string;
}) {
  const res = await api.post('/profile/createProfile', profile);
  return res.data;
}

export async function getProfile(email: string, password: string) {
  const res = await api.post('/profile/getProfile', { email, password });
  return res.data;
}

// Update profile (accept partial payload; server may require auth)
export async function updateProfile(payload: Record<string, any>) {
  const res = await api.put('/profile/updateProfile', payload);
  return res.data;
}

// Products
export async function getAllProducts() {
  const res = await api.get('/product/all');
  return res.data;
}

export async function getProductById(id: string) {
  const res = await api.get(`/product/get/${id}`);
  return res.data;
}

export async function getProductsByLogin(email: string, password: string) {
  const res = await api.post('/product/getByLogin', { email, password });
  return res.data;
}

export async function createProduct(product: any) {
  const res = await api.post('/product/create', product);
  return res.data;
}

export async function deleteProduct(id: string, credentials: { email: string; password: string }) {
  const res = await api.delete(`/product/delete/${id}`, { data: credentials });
  return res.data;
}

// Update product
export async function updateProduct(id: string, payload: Record<string, any>) {
  const res = await api.put(`/product/${id}`, payload);
  return res.data;
}

// Search products (server-side search)
export async function searchProducts(query: { q?: string; location?: string; propertyType?: string; minPrice?: number; maxPrice?: number; amenities?: string[]; page?: number; limit?: number }) {
  const res = await api.get('/product/search', { params: query });
  return res.data;
}

// Get products owned by the current authenticated user
export async function getMyProducts() {
  const res = await api.get('/product/my');
  return res.data;
}

// Boosting
export async function getBoostPlans() {
  const res = await api.get('/boost/plans');
  return res.data;
}

export async function initiateBoost(productId: string, planId: string) {
  const res = await api.post(`/product/${productId}/boost`, { planId });
  return res.data;
}

// Inquiries / messages
export async function createInquiry(payload: { propertyId: string; fromName: string; fromEmail: string; fromPhone: string; message: string }) {
  const res = await api.post('/inquiries', payload);
  return res.data;
}

export async function getInquiries(propertyId?: string) {
  const res = await api.get('/inquiries', { params: propertyId ? { propertyId } : {} });
  return res.data;
}

// Uploads (images)
export async function uploadImage(file: File) {
  const fd = new FormData();
  fd.append('file', file);
  const res = await api.post('/uploads', fd, { headers: { 'Content-Type': 'multipart/form-data' } });
  return res.data;
}

// Upload using fetch (fallback or preferred by some environments)
export async function uploadImageFetch(file: File) {
  const fd = new FormData();
  fd.append('file', file);
  const res = await fetch(`${BASE}/uploads`, {
    method: 'POST',
    body: fd
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Upload failed: ${res.status} ${text}`);
  }
  return res.json();
}

// Favorites
export async function addFavorite(productId: string) {
  const res = await api.post('/favorites', { productId });
  return res.data;
}

export async function getFavorites() {
  const res = await api.get('/favorites');
  return res.data;
}

export default api;
