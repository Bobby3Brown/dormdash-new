import { Property, Landlord } from '../types';

const landlord: Landlord = {
  id: 'landlord-1',
  name: 'Default Landlord',
  phone: '+2348000000000',
  email: 'landlord@example.com',
  verified: true,
  rating: 4.5,
  properties: 3
};

export const mockProperties: Property[] = [
  {
    id: 'prop-1',
    title: 'Studio Near Campus',
    description: 'Cozy studio apartment perfect for students.',
    price: 120000,
    location: 'Akoka, Lagos',
    propertyType: 'apartment',
    bedrooms: 1,
    bathrooms: 1,
    amenities: ['wifi', 'electricity'],
    images: [],
    landlord,
    isBoostingActive: false,
    safetyRating: 4.2,
    views: 120,
    inquiries: 8,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  }
];

export default mockProperties;
