import { NavigationItem } from '../types';

export const navigationItems: NavigationItem[] = [
  { id: 'home', name: 'Home' },
  { id: 'search', name: 'Search' },
  { id: 'boosting', name: 'Boosting' },
  { id: 'auth', name: 'Login' }
];

export default navigationItems;
